package com.example.TelecomManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelecomManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
