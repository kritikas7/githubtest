package com.example.TelecomManagement.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer customerId;

    private String name;
    private Integer phNo;
    private String email;

    @ManyToOne
    @JoinColumn(name = "planId")
    private Plan plan;  // Association with Plan

    @OneToMany(mappedBy = "fromId")
    private List<Call> outgoingCalls;  // Association with Call (outgoing)

    @OneToMany(mappedBy = "toId")
    private List<Call> incomingCalls;  // Association with Call (incoming)

    private String startDuration;
    private String endDuration;
    private String status;

    // Default constructor
    public Customer() {}

    // Parameterized constructor
    public Customer(Integer customerId, String name, Integer phNo, String email, Plan plan, String startDuration, String endDuration, String status) {
        this.customerId = customerId;
        this.name = name;
        this.phNo = phNo;
        this.email = email;
        this.plan = plan;
        this.startDuration = startDuration;
        this.endDuration = endDuration;
        this.status = status;
    }

    // Getters and Setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPhNo() {
        return phNo;
    }

    public void setPhNo(Integer phNo) {
        this.phNo = phNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan planId) {
        this.plan = plan;
    }

    public String getStartDuration() {
        return startDuration;
    }

    public void setStartDuration(String startDuration) {
        this.startDuration = startDuration;
    }

    public String getEndDuration() {
        return endDuration;
    }

    public void setEndDuration(String endDuration) {
        this.endDuration = endDuration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Call> getOutgoingCalls() {
        return outgoingCalls;
    }

    public void setOutgoingCalls(List<Call> outgoingCalls) {
        this.outgoingCalls = outgoingCalls;
    }

    public List<Call> getIncomingCalls() {
        return incomingCalls;
    }

    public void setIncomingCalls(List<Call> incomingCalls) {
        this.incomingCalls = incomingCalls;
    }

    @Override
    public String toString() {
        return "Customer [customerId=" + customerId + ", name=" + name + ", phNo=" + phNo + ", email=" + email + ", plan=" + plan+ ", startDuration=" + startDuration + ", endDuration=" + endDuration + ", status=" + status + "]";
    }
}
