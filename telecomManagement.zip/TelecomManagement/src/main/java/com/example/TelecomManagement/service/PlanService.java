package com.example.TelecomManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TelecomManagement.dao.PlanDao;
import com.example.TelecomManagement.exception.BadRequestException;
import com.example.TelecomManagement.exception.PlanNotFoundException;
import com.example.TelecomManagement.model.Plan;

@Service
public class PlanService {
    @Autowired
    PlanDao planDao;

    public String addPlan(Plan p1) {
        if (p1 == null) {
            throw new BadRequestException("Plan object cannot be null");
        }
        planDao.save(p1);
        return "added";
    }

    public List<Plan> getAll() {
        List<Plan> plans = planDao.findAll();
        if (plans.isEmpty()) {
            throw new PlanNotFoundException("No plans found");
        }
        return plans;
    }

    public List<Plan> getPlanByPname(String pname) {
        List<Plan> plans = planDao.getPlanByName(pname);
        if (plans.isEmpty()) {
            throw new PlanNotFoundException("No plans found with name: " + pname);
        }
        return plans;
    }

    public List<Plan> getPlanBypPrice(Integer price) {
        List<Plan> plans = planDao.getPlanByPrice(price);
        if (plans.isEmpty()) {
            throw new PlanNotFoundException("No plans found with price: " + price);
        }
        return plans;
    }

    public List<Plan> getPlanBypDays(Integer days) {
        List<Plan> plans = planDao.getPlanByDays(days);
        if (plans.isEmpty()) {
            throw new PlanNotFoundException("No plans found with days: " + days);
        }
        return plans;
    }
}

