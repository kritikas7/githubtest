package com.example.TelecomManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TelecomManagement.dao.CustomerDao;
import com.example.TelecomManagement.exception.BadRequestException;
import com.example.TelecomManagement.exception.CustomerNotFoundException;
import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {

    @Autowired
    CustomerDao customerDao;

    public String addCustomer(Customer customer) {
        if (customer == null) {
            throw new BadRequestException("Customer object cannot be null");
        }
        customerDao.save(customer);
        return "ADDED";
    }

    public List<Customer> displayAllCustomers() {
        List<Customer> customerList = customerDao.findAll();
        if (customerList.isEmpty()) {
            throw new CustomerNotFoundException("No customers found");
        }
        return customerList;
    }

    public Optional<Customer> displayCustomer(Integer customerId) {
        Optional<Customer> customer = customerDao.findById(customerId);
        if (customer.isEmpty()) {
            throw new CustomerNotFoundException("Customer not found with ID: " + customerId);
        }
        return customer;
    }

    public Customer displayCustomerByPlan(Plan plan) {
        Optional<Customer> customer = customerDao.getCustomerByPlan(plan);
        if (customer.isEmpty()) {
            throw new CustomerNotFoundException("Customer not found with plan ID: " + plan);
        }
        return customer.get();
    }

    public List<Customer> displayCustomerByStatus(String status) {
        List<Customer> customerList = customerDao.findByStatus(status);
        if (customerList.isEmpty()) {
            throw new CustomerNotFoundException("No customers found with status: " + status);
        }
        return customerList;
    }

    public List<Customer> displayCustomerByPhoneNo(String phoneNo) {
        List<Customer> customerList = customerDao.findByPhone(phoneNo);
        if (customerList.isEmpty()) {
            throw new CustomerNotFoundException("No customers found with phone number: " + phoneNo);
        }
        return customerList;
    }
}
