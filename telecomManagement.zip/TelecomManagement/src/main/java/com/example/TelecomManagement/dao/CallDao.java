package com.example.TelecomManagement.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.TelecomManagement.model.Call;
import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;





@Repository
//@Component
public interface CallDao  extends JpaRepository<Call,Integer>
{

List<Call> getCallByfromId(@Param("fromId")Customer fid);
List<Call> getCallBytoId(@Param("toId")Customer tid);
List<Call> getCallBytotalTime(@Param("totalTime")Float ttid);
List<Call> getCallByplan(@Param("plan")Plan plan);
@Query("SELECT c FROM Call c WHERE c.callDate = :callDate")
List<Call> findCallsByDate(@Param("callDate") Date callDate);

}

