package com.example.TelecomManagement.dao;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;



@Repository
public interface CustomerDao extends JpaRepository <Customer , Integer>
{
	@Query("select c from Customer c where c.status=:status")
	List<Customer> findByStatus(@Param("status")String status);

	@Query("select c from Customer c where c.phNo=:phoneNo")
	List<Customer> findByPhone(@Param("phoneNo")String phoneNo);

	Optional<Customer> getCustomerByPlan(Plan plan);

}
