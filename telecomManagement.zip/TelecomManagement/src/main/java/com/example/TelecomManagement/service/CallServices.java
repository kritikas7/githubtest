package com.example.TelecomManagement.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.example.TelecomManagement.dao.CallDao;
import com.example.TelecomManagement.exception.BadRequestException;
import com.example.TelecomManagement.exception.CallNotFoundException;
import com.example.TelecomManagement.model.Call;
import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;



@Service
public class CallServices {
    @Autowired
    CallDao callDao;

    public List<Call> getCallByfromId(Customer fid) {
        List<Call> callList = callDao.getCallByfromId(fid);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found from ID: " + fid);
        }
        return callList;
    }

    public List<Call> getCallBytoId(Customer tid) {
        List<Call> callList = callDao.getCallBytoId(tid);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found to ID: " + tid);
        }
        return callList;
    }

    public List<Call> getCallByplan(Plan plan) {
        List<Call> callList = callDao.getCallByplan(plan);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found for plan ID: " + plan);
        }
        return callList;
    }

    public List<Call> getCallBytotalTime(Float ttid) {
        List<Call> callList = callDao.getCallBytotalTime(ttid);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found with total time: " + ttid);
        }
        return callList;
    }

    public String addCall(Call call) {
        if (call == null) {
            throw new BadRequestException("Call object cannot be null");
        }
        callDao.save(call);
        return "Added";
    }

    public Call getCallId(Integer cid) {
        Optional<Call> callList = callDao.findById(cid);
        return callList.orElseThrow(() -> new CallNotFoundException("Record not found with ID: " + cid));
    }

    public Call updateCall(Integer callId, Call call) {
        Call existingCall = callDao.findById(callId).orElseThrow(() -> new CallNotFoundException("Call not found with ID: " + callId));
        existingCall.setTotalTime(call.getTotalTime());
        return callDao.save(existingCall);
    }

    public Call deleteCall(Integer callId) {
        Call existingCall = callDao.findById(callId).orElseThrow(() -> new CallNotFoundException("Call not found with ID: " + callId));
        callDao.deleteById(callId);
        return existingCall;
    }

    public List<Call> getAllDetails() {
        List<Call> callList = callDao.findAll();
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No call records found");
        }
        return callList;
    }

    public List<Call> getCallsByDate(Date callDate) {
        try {
            List<Call> calls = callDao.findCallsByDate(callDate);
            if (calls.isEmpty()) {
                throw new CallNotFoundException("No calls found for the given date");
            }
            return calls;
        } catch (Exception e) {
            throw new RuntimeException("Error occurred while fetching calls by date", e);
        }
    }
}
