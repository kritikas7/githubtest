package com.example.TelecomManagement.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
public class Call {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer callId;

    @ManyToOne
    @JoinColumn(name = "fromId", nullable = false)
    private Customer fromId;  // Association with Customer (caller)

    @ManyToOne
    @JoinColumn(name = "toId", nullable = false)
    private Customer toId;  // Association with Customer (receiver)

    @ManyToOne
    @JoinColumn(name = "planId", nullable = false)
    private Plan plan;  // Association with Plan

    @Temporal(TemporalType.DATE)
    private Date callDate;  // Date attribute

    private String startTime;
    private String endTime;
    private Float totalTime;

	

	


    // Default constructor
    public Call() {}
    @Override
    public String toString() {
        return "Call [callId=" + callId + ", fromId=" + fromId + ", toId=" + toId + ", startTime=" + startTime + ", endTime=" + endTime + ", totalTime=" + totalTime + ", plan=" + plan + ", callDate=" + callDate + "]";
    }

    // Parameterized constructor
    public Call(Integer callId, Customer fromId, Customer toId, String startTime, String endTime, Float totalTime,Plan planId, Date callDate) {
    	this.callId = callId;
    	this.fromId = fromId;
    	this.toId = toId;
    	this.startTime = startTime;
    	this.endTime = endTime;
    	this.totalTime = totalTime;
    	this.plan = plan;
        this.callDate = callDate;
    }

    // Getters and Setters
    public Integer getCallId() {
        return callId;
    }

    public void setCallId(Integer callId) {
        this.callId = callId;
    }

    public Customer getFromId() {
    	return fromId;
    }

    public void setFromId(Customer fromId) {
    	this.fromId = fromId;
    }

    public Customer getToId() {
    	return toId;
    }

    public void setToId(Customer toId) {
    	this.toId = toId;
    }

    public Plan getPlanId() {
    	return plan;
    }

    public void setPlanId(Plan planId) {
    	this.plan = planId;
    }

    public Date getCallDate() {
        return callDate;
    }

    public void setCallDate(Date callDate) {
        this.callDate = callDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Float getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Float totalTime) {
        this.totalTime = totalTime;
    }

  
}
