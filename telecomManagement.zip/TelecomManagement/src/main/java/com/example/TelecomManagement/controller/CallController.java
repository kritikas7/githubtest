package com.example.TelecomManagement.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.TelecomManagement.model.Call;
import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;
import com.example.TelecomManagement.service.CallServices;



@RestController
public class CallController {
    @Autowired
    CallServices callServices;

    @GetMapping("/callfrom/{fromid}")
    public List<Call> getCallByfromId(@PathVariable Customer fromid) {
        return callServices.getCallByfromId(fromid);
    }

    @GetMapping("/callto/{toid}")
    public List<Call> getCallBytoId(@PathVariable Customer toid) {
        return callServices.getCallBytoId(toid);
    }

    @GetMapping("/getalldetails")
    public List<Call> getAllDetails1() {
        return callServices.getAllDetails();
    }

    @GetMapping("/callcid/{callid}")
    public Call getCallBycallId(@PathVariable Integer callid) {
        return callServices.getCallId(callid);
    }

    @GetMapping("/calltt/{totaltime}")
    public List<Call> getCallBytotalTime(@PathVariable Float totaltime) {
        return callServices.getCallBytotalTime(totaltime);
    }

    @GetMapping("/callp/{planid}")
    public List<Call> getCallByplan(@PathVariable Plan plan) {
        return callServices.getCallByplan(plan);
    }

    @PostMapping("/call")
    public String addcallDetails(@RequestBody Call call) {
        return callServices.addCall(call);
    }


    @GetMapping("/calls/date/{date}")
    public List<Call> getCallsByDate(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date date) {
        return callServices.getCallsByDate(date);
    }
}
