package com.example.TelecomManagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.TelecomManagement.model.Plan;

@Repository
public interface PlanDao extends JpaRepository<Plan, Integer> {
    @Query("SELECT planId FROM Plan p WHERE p.pname = :pname")
    List<Plan> getPlanByName(@Param("pname") String pname);

    @Query("SELECT planId FROM Plan p WHERE p.price = :price")
    List<Plan> getPlanByPrice(@Param("price") Integer price);

    @Query("SELECT planId FROM Plan p WHERE p.noOfDays = :days")
    List<Plan> getPlanByDays(@Param("days") Integer days);
}
