package com.example.TelecomManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelecomManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelecomManagementApplication.class, args);
	}

}
