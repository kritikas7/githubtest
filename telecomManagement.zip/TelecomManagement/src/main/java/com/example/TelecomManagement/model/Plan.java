package com.example.TelecomManagement.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Plan {
    @Id
    
    private Plan plan;

    private String pname;
    private Integer price;
    private Integer noOfCalls;
    private Integer dataPerDay;
    private Integer noOfMsg;
    private Integer noOfDays;

    @OneToMany(mappedBy = "plan")
    private List<Customer> customers;  // Association with Customer

    @OneToMany(mappedBy = "plan")
    private List<Call> calls;  // Association with Call

	;

    // Default constructor
    public Plan() {}

    // Parameterized constructor
    public Plan(Plan plan, String pname, Integer price, Integer noOfCalls, Integer dataPerDay, Integer noOfMsg, Integer noOfDays) {
        this.plan = plan;
        this.pname = pname;
        this.price = price;
        this.noOfCalls = noOfCalls;
        this.dataPerDay = dataPerDay;
        this.noOfMsg = noOfMsg;
        this.noOfDays = noOfDays;
    }

    // Getters and Setters
    public Plan getplan() {
        return plan;
    }

    public void setplan(Plan plan) {
        this.plan = plan;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getNoOfCalls() {
        return noOfCalls;
    }

    public void setNoOfCalls(Integer noOfCalls) {
        this.noOfCalls = noOfCalls;
    }

    public Integer getDataPerDay() {
        return dataPerDay;
    }

    public void setDataPerDay(Integer dataPerDay) {
        this.dataPerDay = dataPerDay;
    }

    public Integer getNoOfMsg() {
        return noOfMsg;
    }

    public void setNoOfMsg(Integer noOfMsg) {
        this.noOfMsg = noOfMsg;
    }

    public Integer getNoOfDays() {
        return noOfDays;
    }

    public void setNoOfDays(Integer noOfDays) {
        this.noOfDays = noOfDays;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }

    public List<Call> getCalls() {
        return calls;
    }

    public void setCalls(List<Call> calls) {
        this.calls = calls;
    }

    @Override
    public String toString() {
        return "Plan [planId=" + plan + ", pname=" + pname + ", price=" + price + ", noOfCalls=" + noOfCalls + ", dataPerDay=" + dataPerDay + ", noOfMsg=" + noOfMsg + ", noOfDays=" + noOfDays + "]";
    }
}
