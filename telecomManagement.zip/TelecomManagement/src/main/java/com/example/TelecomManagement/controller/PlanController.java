package com.example.TelecomManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.TelecomManagement.exception.BadRequestException;
import com.example.TelecomManagement.exception.PlanNotFoundException;
import com.example.TelecomManagement.model.Plan;
import com.example.TelecomManagement.service.PlanService;

@RestController
public class PlanController {
    @Autowired
    PlanService planService;

    @PostMapping("/plan")
    public String addDetails(@RequestBody Plan p1) {
        if (p1 == null) {
            throw new BadRequestException("Plan object cannot be null");
        }
        return planService.addPlan(p1);
    }

    @GetMapping("/plan")
    public List<Plan> getAllPlan() {
        return planService.getAll();
    }

    @GetMapping("/plan/{pname}")
    public List<Plan> getDetailsByName(@PathVariable String pname) {
        return planService.getPlanByPname(pname);
    }

    @GetMapping("/plan2/{price}")
    public List<Plan> getByPrice(@PathVariable Integer price) {
        return planService.getPlanBypPrice(price);
    }

    @GetMapping("/plan3/{days}")
    public List<Plan> getByDays(@PathVariable Integer days) {
        return planService.getPlanBypDays(days);
    }
}
