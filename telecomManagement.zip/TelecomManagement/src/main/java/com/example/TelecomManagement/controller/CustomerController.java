package com.example.TelecomManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.TelecomManagement.exception.BadRequestException;
import com.example.TelecomManagement.exception.CustomerNotFoundException;
import com.example.TelecomManagement.model.Customer;
import com.example.TelecomManagement.model.Plan;
import com.example.TelecomManagement.service.CustomerService;

@RestController
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/customer")
    public String addCustomerDetails(@RequestBody Customer customer) {
        if (customer == null) {
            throw new BadRequestException("Customer object cannot be null");
        }
        return customerService.addCustomer(customer);
    }

    @GetMapping("/customer")
    public List<Customer> displayAllCustomersDetails() {
        return customerService.displayAllCustomers();
    }

    @GetMapping("/customer/{customerId}")
    public Optional<Customer> getCustomerByCustomerIdDetails(@PathVariable Integer customerId) {
        return customerService.displayCustomer(customerId);
    }

    @GetMapping("/customer1/{planId}")
    public Customer getCustomerByPlan(@PathVariable Plan plan) {
        return customerService.displayCustomerByPlan(plan);
    }

    @GetMapping("/customer2/{status}")
    public List<Customer> getCustomerByStatus(@PathVariable String status) {
        return customerService.displayCustomerByStatus(status);
    }

    @GetMapping("/customer3/{phoneNo}")
    public List<Customer> getCustomerByPhNo(@PathVariable String phoneNo) {
        return customerService.displayCustomerByPhoneNo(phoneNo);
    }
}
